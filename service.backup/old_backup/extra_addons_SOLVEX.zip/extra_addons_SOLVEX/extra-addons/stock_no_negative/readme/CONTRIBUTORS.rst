* Alexis de Lattre <alexis.delattre@akretion.com>
* Vishnu Vanneri <vanneri.odoodev@gmail.com>
* Serpent Consulting Services Pvt. Ltd. <support@serpentcs.com>
* `ForgeFlow S.L. <contact@forgeflow.com>`_:
    * Jordi Ballester
    * Joan Mateu
* `Tecnativa <https://www.tecnativa.com>`_:
    * Pedro M. Baeza
* `Spacefoot <https://www.spacefoot.com>`_:
    * Quentin Delcourte
* Vishnu Vanneri <vvanneri@ioppolo.com.au>
