## Module <om_account_bank_statement_import>

#### 27.01.2023
#### Version 16.0.2.0.0
##### ADD
- statement views

#### 22.07.2022
#### Version 16.0.1.0.0
##### ADD
- initial release
