from odoo import fields, models, api, _
from odoo.exceptions import UserError, ValidationError

from logging import warning as w

class PurchaseOrder(models.Model):
    _inherit = 'purchase.order'

    NEW_PRESTATION_STATE = [
        ('service_done','Satisfaisant'),
        ('non_conforme','Insatisfaisant'),
    ]

    MODALITE_PAIMENT = [
        ('especes','ESPÈCES'),
        ('cheque','CHÈQUE'),
        ('virement_banque','VIREMENT BANCAIRE'),
    ]
    DELAI_PAIMENT = [
        ('immediat','IMMÈDIAT'),
        ('a_terme','À TERME'),
        ('avance','AVANCE'),
    ]

    def _check_article_is_service(self):
        for record in self:
            all_service = all([a.product_id.type == 'service' for a in record.order_line])
            record.is_service_bc = True if all_service else False
    
    def _check_prestation_produit(self):
        if self.requisition_id :
            if self.requisition_id.type_prestation == 'pre_product':
                self.is_stockable = True
            else :
                self.is_stockable = False
        else :
            self.is_stockable = False

    show_service = fields.Boolean(string='Champs po service ?',default=False,)
    state = fields.Selection(selection_add=NEW_PRESTATION_STATE,default='draft')
    is_service_bc = fields.Binary(string='Bon de commande pour un service',default=False,compute=_check_article_is_service,store=False,)
    is_stockable = fields.Boolean(string='is prestation produit ?',default=False,compute=_check_prestation_produit)
    intervenant_ids = fields.Many2many('hr.employee', string='Intervenants',)
    date_start_prest = fields.Date('Date début de la prestation',)
    date_end_prest = fields.Date('Date fin de la prestation',)
    prest_duration = fields.Float('Durée de la prestation',)
    report_non_conform = fields.Binary(string='Rapport',)
    prest_state = fields.Selection(selection=NEW_PRESTATION_STATE, string='État',default='',)
    modalite_paiment = fields.Selection(selection=MODALITE_PAIMENT, string=' Modalité de paiment',default='',)
    delai = fields.Selection(selection=DELAI_PAIMENT,string="Délai de paiment", default=0)
    department_id = fields.Many2one("hr.department", "Départmente",related = 'requisition_id.department_id',readonly=False)
    transfert_out=fields.Many2one('stock.picking',string='Transferts sortie')
    transfert_in=fields.Many2one('stock.picking',string='Transferts entrée')
    def open_transferts(self):
        return {
                "name": "Transferts pour %s" % self.name,
                "type": "ir.actions.act_window",
                "res_model": "stock.picking",
                "view_mode": "tree,form",
                # "views': [(tree_view_id, 'tree'), (form_view_id, 'form')],
                #"view_id": self.env.ref('maintenance_dz.maintenance_workorder_product_tree_view').id,
                "domain": ['|',("id", "=", self.transfert_out.id),("id", "=", self.transfert_in.id)],
            }
    #product_ids
    @api.onchange('order_line')
    def set_product_ids(self):
        for record in self:
            w(f"get product ids")
            record.write({'product_ids':[(6,0,[p.product_id.id for p in record.order_line])]})
            w(f"product_ids {record.product_ids}")
    product_ids = fields.Many2many('product.product', string='Services',compute=set_product_ids)

    def button_verify(self):
        for order in self:
            # if len(order.intervenant_ids) < 1 or not order.date_start_prest or not order.date_end_prest or order.prest_duration <= 0:
            #     raise UserError("Veillez remplir toutes les champs")
            if order.prest_state:
                order.write({'state':order.prest_state})
            else:
                raise UserError("Veillez choisir l'état du prestation")

    def button_cancel(self):
        for order in self:
            if order.show_service and order.state in ['service_done','non_conforme']:
                raise UserError('Vous ne pouvez pas annuler une convention avec un bon de commande terminé')
        super(PurchaseOrder, self).button_cancel()

   
    def print_report(self):
        return  self.env.ref('purchase_service.prestation_service_report').report_action(self)
            
    def btn_service_done(self, force=False):
        self.write({'state': 'service_done'})
    
    def btn_non_conforme(self, force=False):
        self.write({'state': 'non_conforme'})
    
    def btn_create_transfert(self):
        w('transfert*********************************************')
        if self.company_id.location_out and self.order_line:
            pick_id=self.env['stock.picking'].create({'picking_type_id':self.company_id.location_out.id,'is_service_purchase':True})
            self.transfert_out=pick_id.id
            for o in self.requisition_id.line_ids:
                """ pick_id.write({'move_line_ids':(0,0,{'product_id':o.product_id.id,'product_uom_qty':o.product_qty})}) """
                exist=False
                for p in pick_id.move_ids_without_package:
                    if p.product_id==o.product_id:
                        exist=True
                if not exist:
                    self.env['stock.move'].sudo().create({
                                'product_id':o.product_product_id.id,'product_uom_qty':0,
                                'product_uom':o.product_product_id.uom_id.id,
                                'picking_id':pick_id.id,'name':pick_id.name,
                                'company_id':self.company_id.id,'name':self.name,'reference':self.name,
                                'location_id':self.company_id.location_out.default_location_src_id.id,'location_dest_id':self.company_id.location_out.default_location_dest_id.id,})
                """ pick_id.move_ids_without_package=[(0,0,{'product_id':o.product_id.id,'product_uom_qty':o.product_qty})] """
        else:
            raise UserError('vous devez configure le type doperation de sortie')

# class PurchaseRequisitionLine(models.Model):
#     _inherit = 'purchase.requisition.line'

   
#     product_product_id = fields.Many2one('product.product', string='produit pres',change_default=True,)
