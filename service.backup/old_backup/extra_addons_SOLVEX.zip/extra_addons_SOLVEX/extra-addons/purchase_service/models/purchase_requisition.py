from odoo import fields, models, api, _
from odoo.exceptions import UserError, ValidationError
from datetime import datetime

from logging import warning as w

class PurchaseRequisition(models.Model):
    _inherit = 'purchase.requisition'

    state = fields.Selection(selection_add=[('verify','À vérifier'),('done',)], ondelete={'verify': 'set default'})
    state_blanket_order = fields.Selection(selection_add=[('verify','À vérifier'),('done',)],)

    show_service = fields.Boolean(string='Champs po service ?',default=False,)
    type_prestation = fields.Selection([
        ('pre_product', 'Prestation des produits'), ('pre_simple', 'Prestation simple')],
        string='Type de prestation',)
    
    destine = fields.Selection([
        ('contact', 'Contact'), ('machine', 'Machine'),('vehicule', 'Véhicule')],
        string='Destinée à',)
    
    date_demande = fields.Date(string="Date demande", default=fields.Date.context_today)
    date_done = fields.Date(string="Date de confirmation")
    department_id = fields.Many2one("hr.department", "Départmente")
    picking_type_id=fields.Many2one("stock.picking.type", "Livre a")
    
    def _check_bc_is_valide(self):
        for rec in self :
            if rec.purchase_ids :
                for bc in rec.purchase_ids:
                    if bc.state == 'purchase' :
                        rec.bc_is_valide = True
                        break
                    else :
                        rec.bc_is_valide = False
            else :
                rec.bc_is_valide = False

    

    bc_is_valide = fields.Boolean(string='BC is done ?',default=False,compute=_check_bc_is_valide)


    def button_verify(self):
        for record in self:
            record.write({'state':'verify'})

    def nouveau_devis_service(self):
       
        return {
            "name":"Bon commande type service",
            "type":"ir.actions.act_window",
            "res_model":"purchase.order",
            "view_mode":"form,tree",
            "domain":[('show_service','=',True),('requisition_id','=',self.id)],
            "context":{
                "default_show_service":True,
                "default_requisition_id":self.id,
                "default_user_id": self.env.user.id,
                "read_only":True,
            }
        }

    def action_in_progress(self):
        super(PurchaseRequisition,self).action_in_progress()
        self.date_done = datetime.today()
        if self.name != 'New' and self.show_service:
            name=str(self.env['ir.sequence'].sudo().next_by_code('service.purchase.requisition'))
            self.sudo().write({'name':name})
            pr_seq = self.env['ir.sequence'].sudo().search([('code','=','purchase.requisition.purchase.tender')],limit=1)
            pr_seq.sudo().write({'number_next_actual': pr_seq.number_next_actual - 1})

    def open_transferts(self):
        return {
                "name": "Transferts pour %s" % self.name,
                "type": "ir.actions.act_window",
                "res_model": "stock.picking",
                "view_mode": "tree,form",
                # "views': [(tree_view_id, 'tree'), (form_view_id, 'form')],
                #"view_id": self.env.ref('maintenance_dz.maintenance_workorder_product_tree_view').id,
                "domain": ['|',("id", "in", [p.transfert_out.id for p in self.purchase_ids] if self.purchase_ids else [0,0]),("id", "in", [p.transfert_in.id for p in self.purchase_ids] if self.purchase_ids else [0,0])],
            }
    def write(self,vals):
        
        if "ordering_date" not in vals:
            vals["ordering_date"]=datetime.today()
        res=super(PurchaseRequisition,self).write(vals)
        return res
        
class PurchaseRequisitionLine(models.Model):
    _inherit = 'purchase.requisition.line'

    @api.onchange('product_id')
    def _set_product_service_id(self):
        for record in self:
            record.product_service_id = record.product_id.id
    @api.onchange('product_service_id')
    def _set_product_id(self):
        for record in self:
            record.product_id = record.product_service_id.id

    product_service_id = fields.Many2one('product.product', string='prestation',change_default=True,default=lambda self: self.product_id.id)
    product_product_id = fields.Many2one('product.product', string='produit',change_default=True,)
