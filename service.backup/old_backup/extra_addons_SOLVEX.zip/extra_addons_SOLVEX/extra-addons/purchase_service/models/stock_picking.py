from odoo import fields, models, api
from odoo.exceptions import UserError,ValidationError

from logging import warning as w

class StockPicking(models.Model):
    _inherit = 'stock.picking'

    is_service_purchase=fields.Boolean('Achat service',default=False)

    def button_validate(self):
        if self.company_id.location_in and self.move_ids_without_package and self.is_service_purchase:
            o=self.env['purchase.order'].search([('transfert_out','=',self.id)])
            pick_id=self.env['stock.picking'].create({'picking_type_id':self.company_id.location_in.id})
            o.transfert_in=pick_id.id
            for o in self.move_ids_without_package:
                """ pick_id.write({'move_line_ids':(0,0,{'product_id':o.product_id.id,'product_uom_qty':o.product_qty})}) """

                
                self.env['stock.move'].sudo().create({'product_id':o.product_id.id,'product_uom_qty':o.product_qty,
                            'product_uom':o.product_id.uom_id.id,
                            'picking_id':pick_id.id,'name':pick_id.name,
                            'company_id':self.company_id.id,'name':self.name,'reference':self.name,
                            'location_id':self.company_id.location_in.default_location_src_id.id,'location_dest_id':self.company_id.location_in.default_location_dest_id.id,})
                """ pick_id.move_ids_without_package=[(0,0,{'product_id':o.product_id.id,'product_uom_qty':o.product_qty})] """
        else:
            if self.is_service_purchase!=False:
                raise UserError('vous devez configure le type doperation de sortie')
        return super(StockPicking, self).button_validate()