# -*- coding: utf-8 -*-
# from odoo import http


# class PurchaseService(http.Controller):
#     @http.route('/purchase_service/purchase_service', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/purchase_service/purchase_service/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('purchase_service.listing', {
#             'root': '/purchase_service/purchase_service',
#             'objects': http.request.env['purchase_service.purchase_service'].search([]),
#         })

#     @http.route('/purchase_service/purchase_service/objects/<model("purchase_service.purchase_service"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('purchase_service.object', {
#             'object': obj
#         })
