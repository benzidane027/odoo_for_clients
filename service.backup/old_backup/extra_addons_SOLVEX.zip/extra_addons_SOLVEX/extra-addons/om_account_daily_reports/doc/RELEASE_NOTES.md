## Module <om_account_daily_reports>

#### 22.07.2022
#### Version 16.0.1.0.0
##### ADD
- initial release
