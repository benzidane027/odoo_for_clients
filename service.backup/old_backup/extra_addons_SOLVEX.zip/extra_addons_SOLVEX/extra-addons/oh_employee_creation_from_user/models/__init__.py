# -*- coding: utf-8 -*-
from . import employee_creation_from_user

