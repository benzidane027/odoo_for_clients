/* @odoo-module*/
import { Component } from '@odoo/owl'
/**
 * Class representing purchase tiles component.
 */
export class PurchaseTiles extends  Component {}
/**
 * Template for the purchase tiles component.
 */
PurchaseTiles.template = 'PurchaseTiles'
