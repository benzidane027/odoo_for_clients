## Module <purchase_dashboard_advanced>

#### 06.01.2024
#### Version 16.0.1.0.0
#### ADD

- Initial commit for Advanced Purchase Dashboard
