# -*- coding: utf-8 -*-

from . import account_move
from . import followup
from . import followup_partner
from . import partner
from . import settings
