# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from logging import warning as w

class ResConfigSettingspurchase(models.TransientModel):
    _inherit = 'res.config.settings'


    location_in=fields.Many2one('stock.picking.type',string="Emplacement d'entreé",
        readonly=False,
        related='company_id.location_in',
    ) 
    location_out=fields.Many2one('stock.picking.type',string="Emplacement de sortie",
        readonly=False,
        related='company_id.location_out',
    ) 