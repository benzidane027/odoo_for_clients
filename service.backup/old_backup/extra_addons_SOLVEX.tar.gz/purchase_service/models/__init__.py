# -*- coding: utf-8 -*-

from . import purchase_order
from . import purchase_requisition
from . import res_config
from . import res_company
from . import stock_picking
