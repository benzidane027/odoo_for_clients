from odoo import fields, models, api
from odoo.exceptions import ValidationError

from logging import warning as w

class ResCompanypurchase(models.Model):
    _inherit = 'res.company'

    location_in=fields.Many2one('stock.picking.type',string="Emplacement entreé",
    ) 
    location_out=fields.Many2one('stock.picking.type',string="Emplacement sortie",
    ) 