# -*- coding: utf-8 -*-
{
    
    'name': "purchase_service",

    'summary': """
        Short (1 phrase/line) summary of the module's purpose, used as
        subtitle on modules listing or apps.openerp.com
        created by:
        
                raouf
                fodil
                amine
                
        """,

    'description': """
        Long description of module's purpose
    """,

    'author': "SOLVEX",
    'website': "https://www.solvex.dz",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/16.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'purchase',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base','purchase','purchase_requisition','product','stock','hr'],

    # always loaded
    'data': [
        # 'security/ir.model.access.csv',
        'data/data.xml',
        'views/purchase_order_views.xml',
        'views/purchase_requisition_views.xml',
        'views/res_config_view.xml',
        #report
        'report/prestation_service.xml'
    ],
}
