## Module <hr_multi_company>

#### 26.09.2022
#### Version 16.0.1.1.0
##### ADD
- Migrated to Version 16